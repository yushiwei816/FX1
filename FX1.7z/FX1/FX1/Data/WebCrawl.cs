﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FX1.Data
{
	class WebCrawl
	{									   
		
		public FX getData( FX curFX)
		{
			string URL = string.Format(@"http://www.bloomberg.com/quote/{0}:CUR",curFX.sec_name);
			FX res = curFX;
			try
			{
				string htmlCode;
				using (WebClient client = new WebClient())
				{
					  htmlCode = client.DownloadString(URL);
				}
				string tag = "div";
				string pattern = string.Format(@"<{0} class=""price""[^>]*>(?<tegData>.+?)</{0}>", tag.Trim());
				MatchCollection valueCollection = Regex.Matches(htmlCode, pattern);
				if (valueCollection.Count > 0)
				{
					string buffer = valueCollection[0].ToString();
					buffer = buffer.Substring( buffer.IndexOf('>')+1,buffer.LastIndexOf('<') - buffer.IndexOf('>')-1);
					double tmp = 0;
					double.TryParse(buffer, out tmp);
					res.px_last = tmp;					 
					res.px_time = DateTime.Now;
				}
			}
			catch (Exception ex)
			{					   
				throw;
			}				     	  
			return res;									  
		}

		public System.Windows.Forms.HtmlDocument GetHtmlDocument(string html)
		{
			WebBrowser browser = new WebBrowser();
			browser.ScriptErrorsSuppressed = true; //not necessesory you can remove it
			browser.DocumentText = html;
			browser.Document.OpenNew(true);
			browser.Document.Write(html);
			browser.Refresh();
			return browser.Document;
		}

		private string GetContent(string rstring)
		{
			throw new NotImplementedException();
		}
	}

	class FX
	{								 				
		public FX() {
			this.px_last = 0;
		}
		public FX(double px_last, string sec_name ) {
			this.px_last = px_last;
			this.sec_name = sec_name;
		}										 
		public double px_last { get;   set; }
		public string sec_name { get;   set; }		  
		public DateTime px_time { get; set; }
	}
}
