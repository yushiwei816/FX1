﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FX1.Data;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;

namespace FX1
{
	public partial class Form1 : Form
	{
		// should wrap this into a collection if there is a clean/stable data feed.
		private static FX _curAUD = new FX(0,"USDAUD");
		private static FX _curCAD = new FX(0, "USDCAD");
		private static FX _curGBP = new FX(0, "USDGBP");		

		private readonly static object _locker = new object();
		Random _rnd = new Random();
		System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();	 

		public Form1()
		{													  
			InitializeComponent();
		}

		#region GUI_Logic
		private void button1_Click(object sender, EventArgs e)
		{
			if (!backgroundWorker1.IsBusy)
			{
				resetStatus();
				_timer.Start();
				checkedListBox1.Enabled = false;
				backgroundWorker1.RunWorkerAsync();
			}
			else {
				label1.Text = "Busy processing, please wait";
			}
		}

		private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
		{
			label1.Text = "Crawling Live Data...";
			lock (_locker)
			{
				if (checkedListBox1.GetItemChecked(0))
				{
					updateCRY(_curAUD, chart1.Series[0], dataGridView_AUD);
				}

				if (checkedListBox1.GetItemChecked(1))
				{
					updateCRY(_curCAD, chart1.Series[1], dataGridView_CAD);
				}

				if (checkedListBox1.GetItemChecked(2))
				{
					updateCRY(_curGBP, chart1.Series[2], dataGridView_GBP);
				}
				updateStatsPanel();
			}

		}


		private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
		{
			int sum = 0;
			WebCrawl wb = new WebCrawl();
			for (int i = 1; i < 100; i++)
			{
				Thread.Sleep(1000);
				lock (_locker)
				{
					_curAUD = wb.getData(_curAUD);
					_curCAD = wb.getData(_curCAD);
					_curGBP = wb.getData(_curGBP);
					sum = sum + i;
				}
				backgroundWorker1.ReportProgress(i);
				if (backgroundWorker1.CancellationPending)
				{
					e.Cancel = true;
					backgroundWorker1.ReportProgress(0);
					return;
				}
			}
			e.Result = sum;
		}

		private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			_timer.Stop();
			if (e.Cancelled)
			{
				label1.Text = "Cancelled";
				checkedListBox1.Enabled = true;
			}
			else if (e.Error != null)
			{
				label1.Text = e.Error.Message;
			}
			else {												  
				resetStatus();
			}

		}

		private void button_cancel_Click(object sender, EventArgs e)
		{
			if (backgroundWorker1.IsBusy)
			{
				backgroundWorker1.CancelAsync();
			}
		}

		private void tabControl_data_SelectedIndexChanged(object sender, EventArgs e)
		{
			updateStatsPanel();
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			checkedListBox1.SetItemChecked(0, true);
			checkedListBox1.SetItemChecked(1, true);
			checkedListBox1.SetItemChecked(2, true);
			resetStatus();
		}
		#endregion

		#region Utils
		private void resetStatus()
		{
			checkBox_rnd.Enabled = true;
			checkedListBox1.Enabled = true;
			chart1.Series.Clear();
			var series1 = productSeries(_curAUD.sec_name, Color.Green);
			this.chart1.Series.Add(series1);

			var series2 = productSeries(_curCAD.sec_name, Color.Blue);
			this.chart1.Series.Add(series2);

			var series3 = productSeries(_curGBP.sec_name, Color.Black);
			this.chart1.Series.Add(series3);
			chart1.Invalidate();
		}		 

		private void updateCRY(FX _cur, Series _s, DataGridView dv)
		{
			double px_last = getPoint(_cur.px_last, checkBox_rnd.Checked);
			_s.Points.AddXY(DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString(), px_last);
			DataGridViewRow row = (DataGridViewRow)dv.Rows[0].Clone();
			row.Cells[0].Value = _cur.sec_name;
			row.Cells[1].Value = _cur.px_time;
			row.Cells[2].Value = px_last;
			dv.Rows.Add(row);
		}

		private Series productSeries(string name, Color color)
		{
			var series1 = new System.Windows.Forms.DataVisualization.Charting.Series
			{
				Name = name,
				Color = color,
				IsVisibleInLegend = true,
				IsXValueIndexed = true,
				ChartType = SeriesChartType.FastLine
			};
			return series1;
		}

		private double getPoint(double i, bool addRnd)
		{
			if (addRnd)
			{
				double f1 = i * (1 + (_rnd.NextDouble() - 0.5) / 10) + i * (_rnd.Next(10) - 5) / 100.0;
				return f1;
			}
			else {
				double f1 = i;
				return f1;
			}
		}

		private void updateStatsPanel()
		{
			double px_cur = 0, px_prev = 0;
			textBox_cry.Text = tabControl_data.SelectedTab.Text;
			DataGridView curGrid = (DataGridView)(tabControl_data.SelectedTab.Controls[0]);
			if (curGrid.RowCount > 2)
			{
				double.TryParse(curGrid.Rows[curGrid.RowCount - 2].Cells[2].Value.ToString(), out px_cur);
				textBox_px.Text = Math.Round(px_cur, 6).ToString();
			}
			else
			{
				textBox_px.Text = null;
			}

			if (curGrid.RowCount > 3 && px_cur > 0)
			{
				double.TryParse(curGrid.Rows[curGrid.RowCount - 3].Cells[2].Value.ToString(), out px_prev);
				textBox_change.Text = Math.Round((px_cur - px_prev) / px_prev * 100, 6).ToString() + "%";
				if (px_cur == px_prev)
				{
					textBox_change.ForeColor = Color.Black;
				}
				else if (px_prev < px_cur)
				{
					textBox_change.ForeColor = Color.Green;
				}
				else {
					textBox_change.ForeColor = Color.Red;
				}
			}
			else {
				textBox_change.Text = null;
			}
		} 
		#endregion
	}
}
