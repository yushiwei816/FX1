﻿namespace FX1
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.button1 = new System.Windows.Forms.Button();
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
			this.button_cancel = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.checkBox_rnd = new System.Windows.Forms.CheckBox();
			this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
			this.tabControl_data = new System.Windows.Forms.TabControl();
			this.tabPage_AUD = new System.Windows.Forms.TabPage();
			this.dataGridView_AUD = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabPage_CAD = new System.Windows.Forms.TabPage();
			this.dataGridView_CAD = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabPage_GBP = new System.Windows.Forms.TabPage();
			this.dataGridView_GBP = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel_stats = new System.Windows.Forms.Panel();
			this.textBox_change = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox_px = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox_cry = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
			this.tabControl_data.SuspendLayout();
			this.tabPage_AUD.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_AUD)).BeginInit();
			this.tabPage_CAD.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_CAD)).BeginInit();
			this.tabPage_GBP.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_GBP)).BeginInit();
			this.panel1.SuspendLayout();
			this.panel_stats.SuspendLayout();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(14, 9);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(110, 28);
			this.button1.TabIndex = 0;
			this.button1.Text = "FetchData";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// backgroundWorker1
			// 
			this.backgroundWorker1.WorkerReportsProgress = true;
			this.backgroundWorker1.WorkerSupportsCancellation = true;
			this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
			this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
			this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
			// 
			// button_cancel
			// 
			this.button_cancel.Location = new System.Drawing.Point(14, 43);
			this.button_cancel.Name = "button_cancel";
			this.button_cancel.Size = new System.Drawing.Size(110, 23);
			this.button_cancel.TabIndex = 3;
			this.button_cancel.Text = "Cancel";
			this.button_cancel.UseVisualStyleBackColor = true;
			this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label1.Location = new System.Drawing.Point(12, 102);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(0, 17);
			this.label1.TabIndex = 4;
			// 
			// chart1
			// 
			chartArea2.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea2);
			this.chart1.Dock = System.Windows.Forms.DockStyle.Right;
			legend2.Name = "Legend1";
			this.chart1.Legends.Add(legend2);
			this.chart1.Location = new System.Drawing.Point(419, 0);
			this.chart1.Name = "chart1";
			series2.ChartArea = "ChartArea1";
			series2.Legend = "Legend1";
			series2.Name = "Series1";
			this.chart1.Series.Add(series2);
			this.chart1.Size = new System.Drawing.Size(554, 427);
			this.chart1.TabIndex = 5;
			this.chart1.Text = "chart1";
			// 
			// checkBox_rnd
			// 
			this.checkBox_rnd.AutoSize = true;
			this.checkBox_rnd.Location = new System.Drawing.Point(14, 82);
			this.checkBox_rnd.Name = "checkBox_rnd";
			this.checkBox_rnd.Size = new System.Drawing.Size(113, 17);
			this.checkBox_rnd.TabIndex = 7;
			this.checkBox_rnd.Text = "Add RandomWalk";
			this.checkBox_rnd.UseVisualStyleBackColor = true;
			// 
			// checkedListBox1
			// 
			this.checkedListBox1.FormattingEnabled = true;
			this.checkedListBox1.Items.AddRange(new object[] {
            "USDAUD",
            "USDCAD",
            "USDGBP"});
			this.checkedListBox1.Location = new System.Drawing.Point(130, 12);
			this.checkedListBox1.Name = "checkedListBox1";
			this.checkedListBox1.Size = new System.Drawing.Size(73, 49);
			this.checkedListBox1.TabIndex = 8;
			// 
			// tabControl_data
			// 
			this.tabControl_data.Alignment = System.Windows.Forms.TabAlignment.Left;
			this.tabControl_data.Controls.Add(this.tabPage_AUD);
			this.tabControl_data.Controls.Add(this.tabPage_CAD);
			this.tabControl_data.Controls.Add(this.tabPage_GBP);
			this.tabControl_data.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.tabControl_data.Location = new System.Drawing.Point(0, 142);
			this.tabControl_data.Multiline = true;
			this.tabControl_data.Name = "tabControl_data";
			this.tabControl_data.SelectedIndex = 0;
			this.tabControl_data.Size = new System.Drawing.Size(419, 285);
			this.tabControl_data.TabIndex = 9;
			this.tabControl_data.SelectedIndexChanged += new System.EventHandler(this.tabControl_data_SelectedIndexChanged);
			// 
			// tabPage_AUD
			// 
			this.tabPage_AUD.Controls.Add(this.dataGridView_AUD);
			this.tabPage_AUD.Location = new System.Drawing.Point(23, 4);
			this.tabPage_AUD.Name = "tabPage_AUD";
			this.tabPage_AUD.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_AUD.Size = new System.Drawing.Size(392, 277);
			this.tabPage_AUD.TabIndex = 0;
			this.tabPage_AUD.Text = "USDAUD";
			this.tabPage_AUD.UseVisualStyleBackColor = true;
			// 
			// dataGridView_AUD
			// 
			this.dataGridView_AUD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView_AUD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
			this.dataGridView_AUD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView_AUD.Location = new System.Drawing.Point(3, 3);
			this.dataGridView_AUD.Name = "dataGridView_AUD";
			this.dataGridView_AUD.Size = new System.Drawing.Size(386, 271);
			this.dataGridView_AUD.TabIndex = 7;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.HeaderText = "CRY";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.HeaderText = "Time";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			this.dataGridViewTextBoxColumn2.Width = 120;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.HeaderText = "Px_last";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.dataGridViewTextBoxColumn3.Width = 120;
			// 
			// tabPage_CAD
			// 
			this.tabPage_CAD.Controls.Add(this.dataGridView_CAD);
			this.tabPage_CAD.Location = new System.Drawing.Point(23, 4);
			this.tabPage_CAD.Name = "tabPage_CAD";
			this.tabPage_CAD.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage_CAD.Size = new System.Drawing.Size(392, 277);
			this.tabPage_CAD.TabIndex = 1;
			this.tabPage_CAD.Text = "USDCAD";
			this.tabPage_CAD.UseVisualStyleBackColor = true;
			// 
			// dataGridView_CAD
			// 
			this.dataGridView_CAD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView_CAD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
			this.dataGridView_CAD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView_CAD.Location = new System.Drawing.Point(3, 3);
			this.dataGridView_CAD.Name = "dataGridView_CAD";
			this.dataGridView_CAD.Size = new System.Drawing.Size(386, 271);
			this.dataGridView_CAD.TabIndex = 7;
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.HeaderText = "CRY";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			// 
			// dataGridViewTextBoxColumn5
			// 
			this.dataGridViewTextBoxColumn5.HeaderText = "Time";
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			this.dataGridViewTextBoxColumn5.Width = 120;
			// 
			// dataGridViewTextBoxColumn6
			// 
			this.dataGridViewTextBoxColumn6.HeaderText = "Px_last";
			this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			this.dataGridViewTextBoxColumn6.Width = 120;
			// 
			// tabPage_GBP
			// 
			this.tabPage_GBP.Controls.Add(this.dataGridView_GBP);
			this.tabPage_GBP.Location = new System.Drawing.Point(23, 4);
			this.tabPage_GBP.Name = "tabPage_GBP";
			this.tabPage_GBP.Size = new System.Drawing.Size(392, 277);
			this.tabPage_GBP.TabIndex = 2;
			this.tabPage_GBP.Text = "USDGBP";
			this.tabPage_GBP.UseVisualStyleBackColor = true;
			// 
			// dataGridView_GBP
			// 
			this.dataGridView_GBP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView_GBP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
			this.dataGridView_GBP.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView_GBP.Location = new System.Drawing.Point(0, 0);
			this.dataGridView_GBP.Name = "dataGridView_GBP";
			this.dataGridView_GBP.Size = new System.Drawing.Size(392, 277);
			this.dataGridView_GBP.TabIndex = 8;
			// 
			// dataGridViewTextBoxColumn7
			// 
			this.dataGridViewTextBoxColumn7.HeaderText = "CRY";
			this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
			// 
			// dataGridViewTextBoxColumn8
			// 
			this.dataGridViewTextBoxColumn8.HeaderText = "Time";
			this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
			this.dataGridViewTextBoxColumn8.Width = 120;
			// 
			// dataGridViewTextBoxColumn9
			// 
			this.dataGridViewTextBoxColumn9.HeaderText = "Px_last";
			this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
			this.dataGridViewTextBoxColumn9.Width = 120;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.panel_stats);
			this.panel1.Controls.Add(this.checkedListBox1);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.checkBox_rnd);
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.button_cancel);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(419, 142);
			this.panel1.TabIndex = 10;
			// 
			// panel_stats
			// 
			this.panel_stats.Controls.Add(this.textBox_change);
			this.panel_stats.Controls.Add(this.label4);
			this.panel_stats.Controls.Add(this.textBox_px);
			this.panel_stats.Controls.Add(this.label3);
			this.panel_stats.Controls.Add(this.textBox_cry);
			this.panel_stats.Controls.Add(this.label2);
			this.panel_stats.Location = new System.Drawing.Point(230, 9);
			this.panel_stats.Name = "panel_stats";
			this.panel_stats.Size = new System.Drawing.Size(183, 127);
			this.panel_stats.TabIndex = 9;
			// 
			// textBox_change
			// 
			this.textBox_change.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.textBox_change.Location = new System.Drawing.Point(55, 64);
			this.textBox_change.Name = "textBox_change";
			this.textBox_change.Size = new System.Drawing.Size(100, 23);
			this.textBox_change.TabIndex = 5;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(17, 67);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(30, 13);
			this.label4.TabIndex = 4;
			this.label4.Text = "CHG";
			// 
			// textBox_px
			// 
			this.textBox_px.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.textBox_px.Location = new System.Drawing.Point(55, 38);
			this.textBox_px.Name = "textBox_px";
			this.textBox_px.Size = new System.Drawing.Size(100, 23);
			this.textBox_px.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(17, 41);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(19, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Px";
			// 
			// textBox_cry
			// 
			this.textBox_cry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.textBox_cry.Location = new System.Drawing.Point(55, 12);
			this.textBox_cry.Name = "textBox_cry";
			this.textBox_cry.Size = new System.Drawing.Size(100, 23);
			this.textBox_cry.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(17, 15);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(29, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "CRY";
			// 
			// linkLabel1
			// 
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
			this.linkLabel1.LinkVisited = true;
			this.linkLabel1.Location = new System.Drawing.Point(557, 411);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(246, 13);
			this.linkLabel1.TabIndex = 10;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "http://www.bloomberg.com/quote/USDAUD:CUR\r\n";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(973, 427);
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.tabControl_data);
			this.Controls.Add(this.chart1);
			this.MinimumSize = new System.Drawing.Size(989, 466);
			this.Name = "Form1";
			this.Text = "FX realtime display";
			this.Load += new System.EventHandler(this.Form2_Load);
			((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
			this.tabControl_data.ResumeLayout(false);
			this.tabPage_AUD.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_AUD)).EndInit();
			this.tabPage_CAD.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_CAD)).EndInit();
			this.tabPage_GBP.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_GBP)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel_stats.ResumeLayout(false);
			this.panel_stats.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button button1;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		private System.Windows.Forms.Button button_cancel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
		private System.Windows.Forms.CheckBox checkBox_rnd;
		private System.Windows.Forms.CheckedListBox checkedListBox1;
		private System.Windows.Forms.TabControl tabControl_data;
		private System.Windows.Forms.TabPage tabPage_AUD;
		private System.Windows.Forms.DataGridView dataGridView_AUD;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.TabPage tabPage_CAD;
		private System.Windows.Forms.DataGridView dataGridView_CAD;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
		private System.Windows.Forms.TabPage tabPage_GBP;
		private System.Windows.Forms.DataGridView dataGridView_GBP;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel_stats;
		private System.Windows.Forms.TextBox textBox_change;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox_px;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox_cry;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.LinkLabel linkLabel1;
	}
}